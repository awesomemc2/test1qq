Hatena server - by pbsds
======

This is a replacement for the Flipnote Hatena service for the DSi which has ended.
It's written in Python 2.7 and requires Twisted.
Future versions could need PIL aswell.
This project uses Hatenatools, which is also written by me. It can be found here: http://pbsds.net/projects/hatenatools

To use it, simply run server.py.
On the DSi, set the proxy settings to point to this server on port 8080, then access Flipnote Studio as usual. A more detailed guide is on the wiki section.

Documentation on the formats Flipnote Studio uses can be found in the wiki section of this git.